# Wazseic — Developer Portfolio

Statik HTML/CSS/JavaScript kişisel portföy sitesi. Build komutu veya framework kurulumu gerekmez.

## Dosyalar
- `index.html` — sayfa içeriği
- `style.css` — duyarlı tasarım
- `script.js` — footer yılı
- `favicon.svg` — sekme simgesi

## Yayınlama (Vercel)
1. Bu klasörü bir GitHub deposuna yükle.
2. https://vercel.com/new adresinden GitHub deposunu içe aktar.
3. Framework Preset: **Other** (veya otomatik algılanan statik site ayarı).
4. Build Command ve Output Directory alanlarını boş bırak; gerekirse Output Directory için `.` kullan.
5. Deploy seçeneğine bas. Vercel bir `*.vercel.app` adresi verir.

Alternatif olarak Vercel CLI ile:
```bash
npm i -g vercel
vercel
```
İlk kurulum sorularını yanıtla. Üretim yayını için `vercel --prod`.

## Yayınlamadan önce düzenle
`index.html` içindeki Discord ve GitHub bağlantılarını kendi profil bağlantılarınla değiştir. Proje kartlarındaki açıklamaları yalnızca gerçekten yaptığın projelere göre güncelle. Site başlığı ve açıklaması da `index.html` içindeki `<title>` ve `meta name="description"` alanlarında düzenlenebilir.
